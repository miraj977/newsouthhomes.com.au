<header id="masthead" class="site-header">
  <div class="container">
    <div class="row">
      <div class="col-sm-12 col-md-12 col-lg-4 ">
        <div class="site-branding"> <a href="<?php echo site_url();?>" class="logo main_logo">
          <?php if(get_field("banner") || is_front_page() || is_home()){?>
          <img src="<?php echo get_field("logo","option")?>" />
          <?php } else if (is_single() || is_search() || (!get_field("banner")) ){ ?>
          <img src="<?php echo get_field("sticky_logo","option")?>" />
          <?php } else { ?>
          <img src="<?php echo get_field("logo","option")?>" />
          <?php } ?>
          </a> 
			<a href="<?php echo site_url();?>" class="logo sticky_logo"> <img src="<?php echo get_field("sticky_logo","option")?>" /> </a> </div>
        <!-- .site-branding --> 
      </div>
      <div class="col-sm-12 col-md-12 col-lg-8">
        <nav id="site-navigation" class="main-navigation">
          <button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false">
          <?php esc_html_e( 'Primary Menu', 'pictura-creative' ); ?>
          </button>
          <?php
          wp_nav_menu( array(
            'theme_location' => 'menu-1',
            'menu_id' => 'primary-menu',
          ) );
          ?>
        </nav>
      </div>
    </div>
  </div>
</header>
<?php  echo get_template_part( 'template-parts/header/inner', 'page-banner' ); ?>