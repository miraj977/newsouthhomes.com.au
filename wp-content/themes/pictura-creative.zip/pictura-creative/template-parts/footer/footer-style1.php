<footer>
  <?php if(get_field('footer_topbar','option') == 1) {?>
  <div class="footer-top"  style="background-color: <?php echo get_field("footer_top_background_color","option");?>">
    <div class="container">
      <div class="row">
		  <div class="col-sm-3  col-xs-12 align-self-center" data-aos="fade-up" >
			  <a href="<?php echo site_url();?>">
			  <img src="<?php echo get_field('footer_logo','option');?>" />
			  </a> 
		  </div>
		  
		<div class="col-sm-9 col-xs-12 align-self-center" data-aos="fade-up" >
			<ul class="footer_social white_social">
			<?php if(get_field("facebook","option")){?>
			<li><a href="<?php echo get_field("facebook","option");?>" target="_blank" class="facebook" >Facebook</a></li>
			<?php } ?>
				
				<?php if(get_field("instagram","option")){?>
			<li><a href="<?php echo get_field("instagram","option");?>" target="_blank" class="instagram" >Instagram</a></li>
			<?php } ?>
				
				<?php if(get_field("twitter","option")){?>
			<li><a href="<?php echo get_field("twitter","option");?>"  target="_blank" class="twitter" >Twitter</a></li>
			<?php } ?>
				
				<?php if(get_field("youtube","option")){?>
			<li><a href="<?php echo get_field("youtube","option");?>" target="_blank" class="youtube" >Youtube</a></li>
			<?php } ?>
				
				
				<?php if(get_field("google","option")){?>
			<li><a href="<?php echo get_field("google","option");?>" target="_blank" class="google" >Google+</a></li>
			<?php } ?>				
				
				<?php if(get_field("linkedin","option")){?>
			<li><a href="<?php echo get_field("linkedin","option");?>" target="_blank" class="linkedin" >linkedin</a></li>
			<?php } ?>
			</ul>
			</div>
        </div>
    </div>
  </div>
  <?php } ?>
  <div data-aos="fade-up" class="footer-middle" style="background-color: <?php echo get_field("copyright_background_color","option");?>">
    <div class="container">
      <div class="row"> 
		  <div class="col-md-3 col-sm-6 col-xs-6" data-aos="fade-up" >
			 <?php if(get_field("address_1","option")){?>
			  <div class="f_address">
			  <h5>Location 1</h5>
			  <?php echo get_field("address_1","option")?>
				  </div>
			   <?php if(get_field("phone","option")){?>
			  <a href="<?php echo get_field("phone","option");?>">P <?php echo get_field("phone","option");?></a>
			  <?php } ?><?php } ?>
			  
			  <?php if(get_field("address_2","option")){?>
			  <div class="f_address f_address2">
			  <h5>Location 2</h5>
			  <?php echo get_field("address_2","option")?>
				    </div>
			    <?php if(get_field("phone","option")){?>
			  <a href="<?php echo get_field("phone","option");?>">P <?php echo get_field("phone","option");?></a>
			  <?php } ?><?php } ?>
			  			  
		  </div>
		  <div class="col-md-2  col-sm-6 col-xs-6" data-aos="fade-up" >
			<?php dynamic_sidebar("footer-1");?>
		  </div>
		  
		  <div class="col-md-2 col-sm-6 col-xs-6" data-aos="fade-up" >
			   
		  </div>
		  
		  <div class="col-md-2 col-sm-6 col-xs-6" data-aos="fade-up" >
			   
		  </div>
		  
		  
		</div>
    </div>
  </div>
  <?php if(get_field('copyright','option') == 1) {?>
  <div class="copyright" style="background-color: <?php echo get_field("footer_background_color","option");?>">
    <div class="container">
      <div class="row"><div class="col-sm-6"  >
		 <p><?php echo get_field("copy_right_text","option") ?></p>
		  </div>
			<div class="col-sm-6">
				<div class="policy_thanks" ><?php echo get_field("copy_right_links","option");?></div>
				</div>
        </div>
    </div>
  </div>
  <?php } ?>
</footer>
