	<!--- MODAL --->
<div class="enquiry-modal">
		<div class="enquiry-modal__inner">
			
			<div class="enquiry-modal__content">
				<span class="modal-close"><img src="<?php echo get_stylesheet_directory_uri();?>/images/close-black.svg" ?></span>
				<h2>Enquiry Form</h2>
			<div class="form-wrap">
				<?php $e_formId = get_field("enquiry_form","option");?>
			<?php echo do_shortcode('[contact-form-7 id="'.$e_formId.'" ]');?>
				</div>
				</div>
	</div>
</div>
<!-- END MODAL -->